<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Libro;
use App\Models\Busqueda;

class LibroController extends Controller
{
    public function index(Request $request)
    {
        $buscar     = $request->input('buscar');
        $categoria  = $request->input('categoria');
        $pagina     = (int) $request->input('pagina', 1);
        $maxResults = 12;

        $startIndex = ($pagina - 1) * $maxResults;

        $libros = [];

        if ($buscar) {
            $libros = Libro::buscar($buscar, $startIndex, $categoria, $maxResults);

            Busqueda::create([
                'termino'    => $buscar,
                'categoria'  => $categoria,
                'resultados' => $libros['totalItems'] ?? 0,
            ]);
        }

        $totalItems   = $libros['totalItems'] ?? 0;
        $totalPaginas = (int) ceil($totalItems / $maxResults);

        return view('libros.index', compact(
            'buscar',
            'libros',
            'categoria',
            'pagina',
            'totalPaginas'
        ));
    }
}