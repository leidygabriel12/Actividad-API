<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LibroGuardado extends Model
{
     protected $table = 'libros_guardados';
    protected $fillable = ['google_id', 'titulo', 'autor', 'editorial', 'portada'];
}
