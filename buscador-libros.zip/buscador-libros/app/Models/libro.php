<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;

class Libro extends Model
{
    public static function buscar($texto, $startIndex = 0, $categoria = null, $maxResults = 12)
    {
        $apiKey = env('GOOGLE_BOOKS_API_KEY');

        $consulta = $texto;
        if (!empty($categoria)) {
            $consulta .= '+subject:' . $categoria;
        }

        $respuesta = Http::get('https://www.googleapis.com/books/v1/volumes', [
            'q'          => $consulta,
            'startIndex' => $startIndex,
            'maxResults' => $maxResults,
            'key'        => $apiKey,
        ]);

        if ($respuesta->successful()) {
            return $respuesta->json();
        }

        return [];
    }
}