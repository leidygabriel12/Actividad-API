<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador de Libros</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h1 class="text-center mb-4 display-6 fw-bold text-primary">Buscador de Libros</h1>

    <div class="row justify-content-center mb-4">
        <div class="col-md-8">
            <form method="GET" action="{{ route('libros.index') }}">
                <div class="input-group input-group-lg shadow-sm mb-2">
                    <input type="text" name="buscar" class="form-control"
                           placeholder="Ej: Programación PHP, Laravel..."
                           value="{{ $buscar ?? '' }}" required>
                    <button type="submit" class="btn btn-primary px-4">Buscar</button>
                </div>

                <div class="d-flex justify-content-center">
                    <select name="categoria" class="form-select w-auto" onchange="this.form.submit()">
                        <option value="">Todas las categorías</option>
                        <option value="computers"  {{ ($categoria ?? '') == 'computers'  ? 'selected' : '' }}>Computación</option>
                        <option value="fiction"    {{ ($categoria ?? '') == 'fiction'    ? 'selected' : '' }}>Ficción</option>
                        <option value="science"    {{ ($categoria ?? '') == 'science'    ? 'selected' : '' }}>Ciencia</option>
                        <option value="history"    {{ ($categoria ?? '') == 'history'    ? 'selected' : '' }}>Historia</option>
                        <option value="business"   {{ ($categoria ?? '') == 'business'   ? 'selected' : '' }}>Negocios</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    @if(isset($libros['items']) && count($libros['items']) > 0)
        <div class="row row-cols-1 row-cols-md-3 g-4">
            @foreach($libros['items'] as $libro)
                @php
                    $info = $libro['volumeInfo'] ?? [];
                    $portada = $info['imageLinks']['thumbnail'] ?? 'https://via.placeholder.com/128x192?text=Sin+Portada';
                @endphp
                <div class="col">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="text-center pt-3 bg-white">
                            <img src="{{ $portada }}" class="card-img-top img-fluid" style="height: 200px; object-fit: contain;" alt="Portada">
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-truncate">{{ $info['title'] ?? 'Sin título' }}</h5>
                            <p class="card-text text-muted small mb-1">
                                <strong>Autor:</strong> {{ isset($info['authors']) ? implode(', ', $info['authors']) : 'Desconocido' }}
                            </p>
                            <p class="card-text text-muted small mb-3">
                                <strong>Editorial:</strong> {{ $info['publisher'] ?? 'No disponible' }}
                            </p>
                            @if(isset($info['infoLink']))
                                <a href="{{ $info['infoLink'] }}" target="_blank" class="btn btn-outline-primary btn-sm mt-auto">Ver en Google Books</a>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        @if(($totalPaginas ?? 0) > 1)
            <nav class="mt-5">
                <ul class="pagination justify-content-center">
                    @for($i = 1; $i <= min($totalPaginas, 10); $i++)
                        <li class="page-item {{ $i == $pagina ? 'active' : '' }}">
                            <a class="page-link"
                               href="{{ route('libros.index', ['buscar' => $buscar, 'categoria' => $categoria, 'pagina' => $i]) }}">
                                {{ $i }}
                            </a>
                        </li>
                    @endfor
                </ul>
            </nav>
        @endif

    @elseif($buscar)
        <div class="alert alert-warning text-center" role="alert">
            No se encontraron libros que coincidan con la búsqueda.
        </div>
    @endif
</div>

</body>
</html>