<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LibroController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/libros', [LibroController::class, 'index'])->name('libros.index');
Route::post('/libros/guardar', [LibroController::class, 'guardar'])->name('libros.guardar');
Route::get('/libros', [LibroController::class, 'index'])->name('libros.index');