<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador de Libros</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h1 class="text-center mb-4 display-6 fw-bold text-primary">Buscador de Libros</h1>

    <!-- Formulario -->
    <div class="row justify-content-center mb-4">
        <div class="col-md-8">
            <form method="GET" action="<?php echo e(route('libros.index')); ?>">
                <div class="input-group input-group-lg shadow-sm">
                    <input type="text" name="buscar" class="form-control" 
                           placeholder="Ej: Programación PHP, Laravel..." 
                           value="<?php echo e($buscar ?? ''); ?>" required>
                    <button type="submit" class="btn btn-primary px-4">Buscar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Resultados -->
    <?php if(isset($libros['items']) && count($libros['items']) > 0): ?>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php $__currentLoopData = $libros['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $info = $libro['volumeInfo'] ?? [];
                    $portada = $info['imageLinks']['thumbnail'] ?? 'https://via.placeholder.com/128x192?text=Sin+Portada';
                ?>
                <div class="col">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="text-center pt-3 bg-white">
                            <img src="<?php echo e($portada); ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: contain;" alt="Portada">
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-truncate"><?php echo e($info['title'] ?? 'Sin título'); ?></h5>
                            <p class="card-text text-muted small mb-1">
                                <strong>Autor:</strong> <?php echo e(isset($info['authors']) ? implode(', ', $info['authors']) : 'Desconocido'); ?>

                            </p>
                            <p class="card-text text-muted small mb-3">
                                <strong>Editorial:</strong> <?php echo e($info['publisher'] ?? 'No disponible'); ?>

                            </p>
                            <?php if(isset($info['infoLink'])): ?>
                                <a href="<?php echo e($info['infoLink']); ?>" target="_blank" class="btn btn-outline-primary btn-sm mt-auto">Ver en Google Books</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php elseif($buscar): ?>
        <div class="alert alert-warning text-center" role="alert">
            No se encontraron libros que coincidan con la búsqueda.
        </div>
        <div class="d-flex justify-content-center mt-4 gap-2">
    <?php if($pagina > 1): ?>
        <a href="<?php echo e(route('libros.index', ['buscar' => $buscar, 'pagina' => $pagina - 1])); ?>" 
           class="btn btn-outline-secondary">« Anterior</a>
    <?php endif; ?>

    <?php if(isset($libros['totalItems']) && ($pagina * 10) < $libros['totalItems']): ?>
        <a href="<?php echo e(route('libros.index', ['buscar' => $buscar, 'pagina' => $pagina + 1])); ?>" 
           class="btn btn-outline-secondary">Siguiente »</a>
    <?php endif; ?>
</div>
<form method="GET" action="<?php echo e(route('libros.index')); ?>">
    <div class="row g-2 mb-2">
        <div class="col-md-8">
            <input type="text" name="buscar" class="form-control form-control-lg" 
                   placeholder="Ej: Programación PHP, Laravel..." 
                   value="<?php echo e($buscar ?? ''); ?>" required>
        </div>
        <div class="col-md-2">
            <select name="categoria" class="form-select form-select-lg">
                <option value="">Todas</option>
                <option value="computers" <?php echo e(request('categoria') == 'computers' ? 'selected' : ''); ?>>Computación</option>
                <option value="fiction" <?php echo e(request('categoria') == 'fiction' ? 'selected' : ''); ?>>Ficción</option>
                <option value="science" <?php echo e(request('categoria') == 'science' ? 'selected' : ''); ?>>Ciencia</option>
                <option value="history" <?php echo e(request('categoria') == 'history' ? 'selected' : ''); ?>>Historia</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary btn-lg w-100">Buscar</button>
        </div>
    </div>
</form>
<form method="POST" action="<?php echo e(route('libros.guardar')); ?>" class="mt-2">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="google_id" value="<?php echo e($libro['id'] ?? ''); ?>">
    <input type="hidden" name="titulo" value="<?php echo e($info['title'] ?? ''); ?>">
    <input type="hidden" name="autor" value="<?php echo e(isset($info['authors']) ? implode(', ', $info['authors']) : ''); ?>">
    <input type="hidden" name="editorial" value="<?php echo e($info['publisher'] ?? ''); ?>">
    <input type="hidden" name="portada" value="<?php echo e($portada); ?>">
    <button type="submit" class="btn btn-success btn-sm w-100 mt-1">Guardar</button>
</form>
    <?php endif; ?>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\buscador-libros\resources\views/libros/index.blade.php ENDPATH**/ ?>